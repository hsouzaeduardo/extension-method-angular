import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsumoExtensionComponent } from './consumo-extension.component';

describe('ConsumoExtensionComponent', () => {
  let component: ConsumoExtensionComponent;
  let fixture: ComponentFixture<ConsumoExtensionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsumoExtensionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsumoExtensionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
