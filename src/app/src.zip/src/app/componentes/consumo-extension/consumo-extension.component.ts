import { Component, OnInit } from '@angular/core';

import 'src/app/common/sort-extension';

@Component({
  selector: 'app-consumo-extension',
  templateUrl: './consumo-extension.component.html',
  styleUrls: ['./consumo-extension.component.scss']
})
export class ConsumoExtensionComponent implements OnInit {

  constructor() { }
  public orderList:any = [] ;
  private arrCarList = [
    {
    id: 1,
    Nome: "Fusca",
    Fabricante: "VW"
    },{
      id: 2,
      Nome: "Vectra",
      Fabricante: "GM"
    },{
      id: 3,
      Nome: "Ka",
      Fabricante: "Ford"
    },{
      id: 4,
      Nome: "Cerato",
      Fabricante: "Kia"
    },{
      id: 5,
      Nome: "Kicks",
      Fabricante: "Nissan"
    }
];

  ngOnInit(): void {
    this.orderList = this.arrCarList.sortProp('Nome', "desc");

    console.log(this.orderList);
  }

}
