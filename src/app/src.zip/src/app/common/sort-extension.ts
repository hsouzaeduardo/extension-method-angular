export {};
declare global {
  interface Array<T>{
    sortProp(orderProperty:string, order?:string):any;
  }
}

Array.prototype.sortProp = function (orderProperty: string, order?:"asc") {

    if(!order || order=="asc"){
    console.log("asc");
    return this.sort((a,b) => a[orderProperty].localeCompare(b[orderProperty]));
  }else{
    console.log("desc");
    return this.sort((a,b) => a[orderProperty] > b[orderProperty] ? -1 : 1);
  }
};
